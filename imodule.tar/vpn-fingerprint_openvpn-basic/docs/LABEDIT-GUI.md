# Tạo/cấu hình bằng Labedit GUI

> Tên nút thay đổi theo phiên bản Labtainers. Các mục dưới đây mô tả trường thông tin cần cấu hình; đối chiếu với Labedit đã cài. Hướng dẫn chính thức xác nhận dữ liệu cấu hình cuối cùng nằm ở `config/start.config`; Dockerfile và Results có cấu trúc riêng.

1. Trên Ubuntu VM, mở terminal trong môi trường Labtainers và chạy `labedit`.
2. Chọn chức năng tạo lab mới (thường là **New Lab** hoặc **Create Lab**). Điền tên `vpn-fingerprint_openvpn-basic` (chữ thường, không có khoảng trắng). Không ghi đè lab mẫu `cryp-attk-rsa_fermat`.
3. Trong màn hình **Containers/Computers**, tạo lần lượt `client`, `gateway`, `vpn-server`, `web-server`.
   - Tất cả: user `ubuntu`, script `NONE` để dùng `/sbin/init` trong image `labtainer.network2`.
   - `client`: `TERMINALS 1`.
   - `gateway`: `TERMINALS 1`.
   - `vpn-server`, `web-server`: `TERMINALS 0`.
4. Trong **Networks**, tạo `client-net`, mask `10.0.1.0/24`, network gateway `10.0.1.254`; tạo `external-net`, mask `10.0.2.0/24`, network gateway `10.0.2.254`. Các IP `.254` là gateway của bridge Labtainer, không phải router mô phỏng.
5. Gán IP mỗi container:
   - `client`: `client-net 10.0.1.100`, **LAB GATEWAY** `10.0.1.1`.
   - `gateway`: `client-net 10.0.1.1`, `external-net 10.0.2.1`; không đặt **LAB GATEWAY** cho router hai giao diện.
   - `vpn-server`: `external-net 10.0.2.10`, **LAB GATEWAY** `10.0.2.1`.
   - `web-server`: `external-net 10.0.2.20`, **LAB GATEWAY** `10.0.2.1`.
6. Lưu lab. Đóng Labedit, sao chép nội dung thư mục trong gói ZIP vào `$LABTAINER_DIR/labs/vpn-fingerprint_openvpn-basic/`, cho phép ghi đè các tệp mẫu vừa tạo. Giữ tên Dockerfile `Dockerfile.vpn-fingerprint_openvpn-basic.<container>.student`.
7. Mở `config/start.config`, xác nhận Labedit đã lưu đúng hai network, bốn container và IP. Dùng phiên bản hoàn chỉnh trong gói nếu trường GUI không hỗ trợ tất cả các tùy chọn.
8. Với bản Labtainers dùng cấu hình instructor hiện đại, kiểm tra `instr_config/results.config` và `instr_config/goals.config`. Bản phát hành cũ có thể có màn hình Results riêng; nếu GUI tạo một tệp `results.dat`, đừng giả định file đó được bản Labtainers hiện tại đọc tự động. Giữ nguyên cấu hình `instr_config` và xác thực bằng `checklab.py`/`gradelab`.
9. Build và smoke-test theo `README.md`. Nếu build thất bại ngay ở bước ADD một archive rỗng, chạy công cụ setup/rebuild của bản Labtainers đã cài để tạo lại các archive trong từng container rồi chạy `rebuild -f vpn-fingerprint_openvpn-basic`.

## Những điều cần xác minh theo bản cài [CẦN KIỂM TRA]

- Nhãn/nút chính xác trong cửa sổ Labedit.
- Lệnh và đường dẫn đầy đủ để gọi `labedit` trên VM của trường.
- Phiên bản Labtainers có đọc `instr_config/results.config`/`goals.config` hay dùng cấu hình Results cũ. Kiểm tra cấu trúc của lab mẫu sẵn có và lệnh `checklab.py` trong thư mục instructor.
