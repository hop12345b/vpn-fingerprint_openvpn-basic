# Instructor smoke test / kiểm tra trước khi phát hành

## Kiểm tra cú pháp mã nguồn (host Labtainers VM)

```bash
cd "$LABTAINER_DIR/labs/vpn-fingerprint_openvpn-basic"
bash -n scripts/gateway-startup.sh scripts/vpn-startup.sh scripts/web-startup.sh
python3 -m py_compile scripts/detect_openvpn.py scripts/evaluate.py
```

## Kiểm tra cấu trúc Labtainer (host Labtainers VM)

```bash
cd "$LABTAINER_DIR/scripts/labtainer-instructor"
python3 ../../scripts/designer/bin/checklab.py vpn-fingerprint_openvpn-basic
```

Đường dẫn script kiểm tra có thể khác theo bản Labtainers; tìm `checklab.py` dưới `$LABTAINER_DIR/scripts/labtainer-instructor/bin/` nếu lệnh trên không tồn tại.

## Build sạch (host Labtainers VM)

```bash
cd "$LABTAINER_DIR/scripts/labtainer-student"
rebuild -f vpn-fingerprint_openvpn-basic
```

## Smoke test (terminal container)

```bash
# gateway
ip -br addr
sudo systemctl status vpn-fingerprint-gateway --no-pager
sudo tcpdump -D
sudo tshark --version | head -n 2

# vpn-server, từ host Labtainers VM nếu server không mở terminal
# Thay <container-id> bằng đúng tên container đang chạy:
docker ps --format 'table {{.Names}}\t{{.Status}}'
docker exec <container-id> systemctl status vpn-fingerprint-openvpn --no-pager

# web-server
docker exec <web-container-id> curl -I http://10.0.2.20/
```

## Chấm thử

1. Chạy lab như sinh viên, tạo đủ `baseline.pcap` và `vpn-traffic.pcap`.
2. Cập nhật các tham số trong `detect_openvpn.py` để tạo ra `DETECTION=NO_OPENVPN` trên baseline và `DETECTION=OPENVPN` trên capture VPN.
3. Chạy `python3 evaluate.py baseline.pcap vpn-traffic.pcap` trên gateway, xác nhận có marker `LAB1_RESULT_PASS`.
4. Chạy `stoplab`, sau đó dùng công cụ instructor tương ứng để grading. Nếu goal vẫn false, mở artifact stdout trong thư mục kết quả sinh viên và xác minh parser có nhận `gateway:*.stdout` ở bản hiện tại hay không.

**Giới hạn xác minh:** bộ mã nguồn này được dựng theo quy ước tài liệu Labtainer và được kiểm tra cú pháp. Môi trường tạo file hiện tại không có Docker/Labtainer chạy được nên chưa thể xác nhận build end-to-end trên VM của bạn. Bước smoke test trên là bắt buộc trước khi dùng để chấm sinh viên.
