# HƯỚNG DẪN THỰC HÀNH LAB 1

## Phát hiện dấu hiệu OpenVPN từ gateway

**Tên lab:** `vpn-fingerprint_openvpn-basic`  
**Thời lượng:** 60 phút  
**Đối tượng:** Sinh viên ATTT năm 3-4; biết Linux và Python cơ bản.  
**Môi trường:** Labtainers trên Ubuntu; bốn container và hai subnet riêng.

## 1. Mục tiêu

Sau khi hoàn thành, sinh viên có thể thu thập hai bộ PCAP tại gateway, dùng `tshark` kiểm tra cổng UDP và kích thước frame, điều chỉnh tham số có sẵn trong `detect_openvpn.py`, rồi đánh giá kết quả bằng precision và recall. Không cần tự viết script phát hiện từ đầu.

## 2. Sơ đồ mạng

| Container | Địa chỉ | Vai trò |
|---|---|---|
| `client` | `10.0.1.100` | Tạo HTTP thường hoặc kết nối OpenVPN |
| `gateway` | `10.0.1.1`, `10.0.2.1` | Router, điểm thu thập PCAP, cài `tcpdump` và `tshark` |
| `vpn-server` | `10.0.2.10` | OpenVPN qua UDP/1194 |
| `web-server` | `10.0.2.20` | Máy chủ HTTP port 80 |

`client-net`: `10.0.1.0/24`. `external-net`: `10.0.2.0/24`.

> Các khóa và cấu hình VPN trong bài chỉ dùng trong mạng lab biệt lập, không dùng cho hệ thống thật.

## 3. Khởi động và kiểm tra dịch vụ (5 phút)

Trên terminal Labtainers host, chạy:

```bash
cd "$LABTAINER_DIR/scripts/labtainer-student"
labtainer vpn-fingerprint_openvpn-basic
```

Trong terminal của `client`:

```bash
ip -br addr
ip route
curl -i --max-time 5 http://10.0.2.20/
```

Trang HTTP phải trả về nội dung chứa `WEB_SERVER_OK`. Trong terminal `gateway`:

```bash
ip -br addr
ip route
sudo systemctl status vpn-fingerprint-gateway --no-pager
sudo tcpdump --version
 tshark --version | head -n 2
```

Nếu `sudo` hỏi mật khẩu, mật khẩu được cấu hình trong lab là `ubuntu`.

## 4. Thu baseline HTTP (10 phút)

**Bước A - gateway:** khởi động thu thập trong 25 giây:

```bash
sudo timeout 25s tcpdump -i any -nn -U \
  '(tcp port 80 or udp port 1194)' \
  -w /home/ubuntu/baseline.pcap
```

Trong khi lệnh đang chạy, chuyển sang terminal `client` và tạo nhiều yêu cầu HTTP:

```bash
for i in $(seq 1 10); do curl -sS --max-time 3 http://10.0.2.20/ >/dev/null; sleep 0.3; done
echo BASELINE_HTTP_GENERATED
```

Đợi tcpdump kết thúc. Kiểm tra trên `gateway`:

```bash
ls -lh /home/ubuntu/baseline.pcap
sudo tshark -r /home/ubuntu/baseline.pcap -q -z io,phs
```

## 5. Thu lưu lượng OpenVPN (15 phút)

**Bước A - client:** khởi động OpenVPN ở chế độ daemon:

```bash
sudo openvpn --config /home/ubuntu/client.ovpn \
  --daemon --writepid /tmp/openvpn-client.pid \
  --log /tmp/openvpn-client.log
sleep 2
ip addr show tun0
ip route get 10.0.2.20
```

Kiểm tra HTTP vẫn truy cập được qua tunnel:

```bash
curl -i --max-time 5 http://10.0.2.20/
```

Nếu tunnel chưa lên, xem `/tmp/openvpn-client.log`; không tiếp tục thu PCAP cho đến khi sửa xong.

**Bước B - gateway:** chạy lệnh dưới đây; khi tcpdump bắt đầu thì chuyển sang `client`:

```bash
sudo timeout 25s tcpdump -i any -nn -U \
  '(tcp port 80 or udp port 1194)' \
  -w /home/ubuntu/vpn-traffic.pcap
```

Trên `client`, tạo yêu cầu HTTP qua tunnel:

```bash
for i in $(seq 1 10); do curl -sS --max-time 3 http://10.0.2.20/ >/dev/null; sleep 0.3; done
echo VPN_HTTP_GENERATED
```

Khi tcpdump kết thúc, dừng VPN ở `client`:

```bash
sudo kill "$(cat /tmp/openvpn-client.pid)"
```

## 6. Phân tích với tshark (10 phút)

Các lệnh sau chạy trong terminal `gateway`:

```bash
sudo tshark -r /home/ubuntu/baseline.pcap -Y tcp -T fields \
  -e frame.len -e ip.src -e ip.dst -e tcp.srcport -e tcp.dstport | head -n 20
sudo tshark -r /home/ubuntu/vpn-traffic.pcap -Y udp -T fields \
  -e frame.len -e ip.src -e ip.dst -e udp.srcport -e udp.dstport | head -n 30
sudo tshark -r /home/ubuntu/vpn-traffic.pcap -Y 'udp.port == 1194' -T fields \
  -e frame.len -e udp.srcport -e udp.dstport | head -n 30
```

Ghi lại: số gói UDP, cổng UDP nguồn/đích, khoảng kích thước frame thường gặp và khác biệt giữa hai PCAP. Ở baseline, HTTP chủ yếu là TCP/80. Ở capture VPN, gateway nhìn thấy phiên UDP/1194 giữa client và VPN server; lưu lượng HTTP bên trong tunnel không xuất hiện như phiên TCP/80 đi trực tiếp từ client đến web-server.

## 7. Điều chỉnh rule và đánh giá (10 phút)

Mở `/home/ubuntu/detect_openvpn.py` trên `gateway` bằng editor có sẵn, ví dụ:

```bash
nano /home/ubuntu/detect_openvpn.py
```

Chỉ sửa bốn hằng số ở đầu file dựa trên số liệu PCAP:

```python
VPN_UDP_PORT = 1195
MIN_FRAME_SIZE = 100
MAX_FRAME_SIZE = 1000
MIN_MATCHING_PACKETS = 999
```

Yêu cầu: cổng đúng theo PCAP; dải kích thước bao phủ các gói phù hợp; ngưỡng số gói không được cao hơn số quan sát được của một capture VPN hợp lệ và vẫn đủ cao để tránh kết luận chỉ từ một gói đơn lẻ. Giữ nguyên phần logic bên dưới.

Chạy lần lượt:

```bash
cd /home/ubuntu
python3 detect_openvpn.py baseline.pcap
python3 detect_openvpn.py vpn-traffic.pcap
python3 evaluate.py baseline.pcap vpn-traffic.pcap
```

Kết quả mong muốn:

- `baseline.pcap` -> `DETECTION=NO_OPENVPN`
- `vpn-traffic.pcap` -> `DETECTION=OPENVPN`
- `evaluate.py` -> `TP=1 FP=0 TN=1 FN=0`, precision 100%, recall 100%, và `LAB1_RESULT_PASS`.

Các metric ở đây tính trên **hai file kiểm thử** được gán nhãn sẵn, dùng để kiểm tra bài lab; không đại diện cho hiệu năng của bộ phát hiện trên mọi loại lưu lượng thực tế.

## 8. Câu hỏi cuối bài (5 phút)

1. Những trường nào trong đầu ra `tshark` giúp phân biệt hai capture?
2. Vì sao gateway nhìn thấy UDP/1194 nhưng không thấy HTTP của client dưới dạng TCP/80 trực tiếp khi dùng tunnel?
3. `MIN_MATCHING_PACKETS` quá thấp có thể gây vấn đề gì? Quá cao thì sao?
4. Vì sao phát hiện theo port và packet size không đủ để kết luận chắc chắn mọi lưu lượng đó đều là OpenVPN?
5. Nêu một trường hợp sử dụng VPN hợp lệ trong doanh nghiệp và giải thích vì sao cần đối chiếu với chính sách thay vì tự động kết luận vi phạm.

## 9. Nộp bài và Checkwork

Trên terminal host Labtainers:

```bash
stoplab vpn-fingerprint_openvpn-basic
```

Ghi lại vị trí file ZIP kết quả do Labtainers in ra. Sau đó chạy:

```bash
checkwork vpn-fingerprint_openvpn-basic
```

Nếu phiên bản Labtainers không hỗ trợ `checkwork` tại student side, dùng `stoplab` để đóng gói kết quả và yêu cầu giảng viên kiểm tra bằng công cụ instructor tương ứng.

## 10. Khắc phục nhanh

- HTTP không truy cập được: kiểm tra trạng thái `vpn-fingerprint-web`, IP của web-server, route từ client và route forwarding ở gateway.
- VPN không lên: kiểm tra log `/tmp/openvpn-client.log`, log server bằng `sudo journalctl -u vpn-fingerprint-openvpn --no-pager -n 50`, port UDP/1194 và thiết bị `/dev/net/tun`.
- PCAP rỗng: đảm bảo tcpdump đã chạy trước vòng lặp `curl`; xác nhận interface `any` và đường dẫn file.
- `tshark` không đọc được: kiểm tra `sudo tshark -r <file.pcap> -q` và tên file.
- Detection không khớp: xem `PORT_MATCHES`, `MATCHED_PACKETS`, rồi chỉnh port, frame-size và minimum threshold.
- Checkwork chưa đạt: chạy `evaluate.py` cho cả hai file, xác nhận marker `LAB1_RESULT_PASS`, sau đó mới `stoplab`/`checkwork`.
